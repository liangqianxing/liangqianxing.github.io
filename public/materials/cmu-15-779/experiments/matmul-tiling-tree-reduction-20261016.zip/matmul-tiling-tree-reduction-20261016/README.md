# 矩阵分块与树形归约

本包是 CMU 15-779 学习记录 07 的冻结代码和原始 CPU 结果。

使用 Python 3.11：

```bash
python3.11 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python 26_matmul_tiling.py --output results/matmul-rerun.json
.venv/bin/python 26_matmul_tiling.py --m 3 --k 5 --n 7 --tile 4 --output results/rectangular-rerun.json
.venv/bin/python 27_tree_reduction.py --output results/reduction-rerun.json
.venv/bin/python -m unittest discover -s tests -v
```

包内只含 7 项矩阵测试；完整代码版本另有归约及 Attention 测试。JSON 中保存的是 2026-10-16 的原始结果，复跑请另存。读取次数与依赖深度不是 GPU 测量。cuda/26_matmul_tiling.cu 尚未编译或运行，CPU 测试不能证明它在 GPU 上安全或快速。

代码版本：https://github.com/liangqianxing/cmu-15-779-labs/tree/201587e7b00637567e969368d3085a6ce490154c
