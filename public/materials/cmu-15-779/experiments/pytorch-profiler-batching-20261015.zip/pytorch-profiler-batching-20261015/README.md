# CMU 15-779 学习记录 05 配套代码

Profiler、算子调用与批量推理。这里是对照 ML Systems 基础编写的个人 CPU 实验，不是 CMU 官方作业；数字是本仓库练习编号。

## 环境

本次记录使用 macOS arm64、Python 3.11.15、PyTorch 2.14.1、NumPy 2.4.6。所有脚本独立运行，不训练或读取模型参数文件。

```bash
python3.11 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python 22_profile_forward.py
.venv/bin/python 23_profile_batching.py
.venv/bin/python 24_batch_size_sweep.py --output results/24_batch_size_sweep-rerun.json
```

`24` 不传 `--output` 时会覆盖同目录中的原始结果；上面的命令另存复跑结果。

## 内容

- `22_profile_forward.py`：预热后记录一次前向计算。1000 个样本，2 次 linear、2 次 addmm、1 次 relu；Profiler 事件有嵌套关系。
- `23_profile_batching.py`：同一组 1000 个输入，逐个调用与一次整批调用。两者输出近似一致；linear 调用分别为 2000 次与 2 次。性能计时在 Profiler 外进行。
- `24_batch_size_sweep.py`：固定 1000 个样本和 1 个 CPU 线程，扫描 batch size 1、4、16、64、128、256、1000。每档都执行同一套分批、切片、前向计算与一次拼接流程，并验证输出和算子调用次数。
- `results/24_batch_size_sweep.json`：2026-10-15 16:00（Asia/Shanghai）的原始测量，含环境、脚本 SHA-256、计时协议、中位耗时、四分位距及调用次数。

原始结果中，完整处理 1000 个样本的时间由 batch size 1 的约 8.1494 ms，降到 batch size 1000 的约 0.0130 ms。这只代表当前 25 参数小网络的 CPU 实验；计时不含创建输入与模型、Profiler、输出验证或写文件，也没有测在线请求等待凑批的延迟。

## 尾批检查

```bash
.venv/bin/python 24_batch_size_sweep.py --samples 7 --batch-sizes 1 3 10 --output results/remainder-rerun.json
```

它同时覆盖不能整除的尾批和 batch size 大于样本总数的情况。调用次数断言针对本次 PyTorch CPU 执行路径；不同后端或版本的事件可能不同。

## 入口

- 文章：https://liangqianxing.github.io/posts/cmu-15-779-profiler-operator-batching/
- 代码仓库：https://github.com/liangqianxing/cmu-15-779-labs
