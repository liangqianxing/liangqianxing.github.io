# pytorch-models-20261015

本包对应学习记录 02，包含带偏置线性回归、nn.Linear、nn.Module 与 ReLU 练习。

05 至 08 未固定随机种子，数值末位可能变化。10 使用的三个比较点已包含在 25 个训练点中。

## 环境与运行

在解压后的本目录执行：

```bash
python3.11 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python 04_linear_bias.py
.venv/bin/python 05_nn_linear.py
.venv/bin/python 06_two_inputs.py
.venv/bin/python 07_custom_model.py
.venv/bin/python 08_square.py
.venv/bin/python 09_square_relu.py
.venv/bin/python 10_more_data.py
```

源代码仓库：https://github.com/liangqianxing/cmu-15-779-labs

学习专题：https://liangqianxing.github.io/learning/cmu-15-779/
