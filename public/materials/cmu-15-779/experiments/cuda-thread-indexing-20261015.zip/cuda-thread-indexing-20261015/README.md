# CMU 15-779 学习记录 06 配套代码

CUDA 线程索引与边界检查。这是一维向量加法的个人配套练习，不是 CMU 官方作业。

## 已验证与未验证

- `25_cuda_indexing.py` 用 CPU 循环演示 block/thread 到元素下标的映射，已验证输出值及每个元素恰好写一次。
- `results/25_cuda_indexing.json` 保存 10 个元素、每块 4 个线程的原始结果和六组边界案例。
- `results/25_indexing_17_8.json` 保存 17 个元素、每块 8 个线程的原始结果。
- `cuda/25_vector_add.cu` 是对应的 CUDA C++ 源码；2026-10-15 本机没有 CUDA 设备、nvcc 或 nvidia-smi，未编译、未执行。
- MPS 可用不能作为这份 CUDA C++ 程序已执行的证据。CPU 检查不验证 GPU 调度、设备内存访问或性能。

## 运行 CPU 演示

本次环境：macOS arm64、Python 3.11.15、PyTorch 2.14.1、NumPy 2.4.6。

```bash
python3.11 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python 25_cuda_indexing.py --output results/25_cuda_indexing-rerun.json
.venv/bin/python 25_cuda_indexing.py --n 17 --threads 8 --output results/25_indexing_17_8-rerun.json
```

使用 `--output` 另存复跑结果，保留随附的原始测量。默认配置应有 3 个 block、12 个逻辑线程，其中 2 个越界线程跳过写入；另一配置有 3 个 block、24 个逻辑线程，其中 7 个跳过写入。

CUDA 环境中的编译、执行和设备内存检查命令在 `cuda/README.md`。这些是验证方式，当前没有 GPU 执行结果。

## 入口

- 文章：https://liangqianxing.github.io/posts/cmu-15-779-cuda-thread-indexing/
- 代码：https://github.com/liangqianxing/cmu-15-779-labs/tree/2f21dd338cf2e6a1e129d951993d5f8e5dd56ba1
