# CMU 15-779 学习记录 04 配套代码

多输出线性层、ReLU 与绝对值网络。代码为 2026-10-15 整理时的冻结版本，独立运行，不依赖模型参数文件。

## 环境与运行

本次复跑：Python 3.11、PyTorch 2.14.1、NumPy 2.4.6，Mac CPU。

```bash
python3.11 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python 16_matmul.py
.venv/bin/python 17_multi_output.py
.venv/bin/python 18_relu_steps.py
.venv/bin/python 19_learn_abs.py
```

## 文件与结果

- `16_matmul.py`：手动矩阵乘法与相同参数的 `nn.Linear` 对照，最后输出 `True`。
- `17_multi_output.py`：两个输入特征、两个输出，输出为 `[[9, 4], [19, 10], [29, 16]]`。
- `18_relu_steps.py`：手动设置参数实现绝对值，输入 `[-2, -1, 0, 1, 2]`，输出 `[2, 1, 0, 1, 2]`。附件保留原始 ReLU 版本。文章中跳过 ReLU 的全零结果是整理时的额外对照，可将 `activated = relu(hidden)` 临时改为 `activated = hidden` 验证。
- `19_learn_abs.py`：随机种子 0，`1 → 8 → 1` 网络，21 个样本，SGD 学习率 0.05，训练 3000 步。训练集均方误差约 `0.00005678`，检查输入 `[-0.8, 0, 0.8]` 的预测约 `[0.8022, 0.0227, 0.8001]`。

最后三个检查点属于训练集；损失下降不保证每个点的误差都下降。不同运行环境的浮点末位可能变化。

## 博客与代码仓库

- 记录：https://liangqianxing.github.io/posts/cmu-15-779-pytorch-linear-relu-absolute-value/
- 专题：https://liangqianxing.github.io/learning/cmu-15-779/
- 代码：https://github.com/liangqianxing/cmu-15-779-labs
