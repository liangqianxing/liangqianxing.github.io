# CMU 15-779 配套 CPU 实验

Attention、在线 Softmax 与 KV cache。18 项归约/Attention/KV cache 测试可在本包中运行。

固定 GitHub 版本：https://github.com/liangqianxing/cmu-15-779-labs/tree/9261bea6aedf31cdccbbab2541ca693fc97b3743

原始代码与结果冻结于 2026-10-19。个人脚本编号不是官方作业。真实 GPU 实验按学习安排跳过；课程尚未完成。

```bash
python3.11 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python 28_attention_online_softmax.py --output results/attention-rerun.json
.venv/bin/python 29_kv_cache.py --output results/kv-cache-rerun.json
.venv/bin/python -m unittest discover -s tests -v
```

使用 --output 另存复跑报告，保留原始结果。TorchInductor 的 --compile 运行还需可用的本机编译工具链；首调用成本与后续计时分开。
