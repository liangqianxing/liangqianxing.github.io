# pytorch-batching-20261015

本包对应学习记录 03，包含分批训练、保存参数、独立预测、批量计时与矩阵乘法。

13 会重新生成当前目录中的 square_model.pth。14 和 15 可以直接加载包内的参数文件。15 当前使用 1 个样本，改成 1000 可复现另一组计时。12 中的三个比较点包含在训练集里；13 和 14 使用未参与训练的三个点。

## 环境与运行

在解压后的本目录执行：

```bash
python3.11 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python 11_batches.py
.venv/bin/python 12_mini_batch.py
.venv/bin/python 13_save_load.py
.venv/bin/python 14_predict.py
.venv/bin/python 15_batch_benchmark.py
.venv/bin/python 16_matmul.py
```

源代码仓库：https://github.com/liangqianxing/cmu-15-779-labs

学习专题：https://liangqianxing.github.io/learning/cmu-15-779/
