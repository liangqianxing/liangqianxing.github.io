# KV 页粒度 CPU 实验

CMU 15-779 个人配套实验的冻结发布包，原始报告保留不变，复跑请使用另存路径。

安装与命令见 course/project/README.md。运行项目脚本可重做 210 组配置；分析脚本默认读取随附原始报告。tests/ 仅含两项项目测试，results/38_cpu_tests.txt 是完整仓库 54 项测试日志。存储与复制计数可复现，CPU 毫秒数会波动。

FILES.sha256.json 保存本包各文件 SHA-256；它不包含自身。
