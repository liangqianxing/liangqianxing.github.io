# CMU 15-779 记录 10 至 13：CPU 实验冻结包

2026-10-19 冻结源聊天已运行完成的 31 至 37 号脚本及原始结果。个人配套实验，不是官方作业或整门课程完成证明。原始 JSON 的 script_sha256 对应包内脚本。

环境：Python 3.11、PyTorch 2.14.1、NumPy 2.4.6。创建 venv 后 pip install -r requirements.txt。

```bash
python 31_cpu_parallelism.py --gloo --output results/31-rerun.json
python 32_pipeline_schedule.py --output results/32-rerun.json
python 33_paged_kv_cache.py --output results/33-rerun.json
python 34_speculative_sampling.py --output results/34-rerun.json
python 35_lora_quantization.py --output results/35-rerun.json
python 36_moe_dispatch.py --output results/36-rerun.json
python 37_continuous_batching.py --output results/37-rerun.json
python -m unittest discover -s tests -v
```

包内 22 项测试；results/37_cpu_tests.txt 为包含此前实验在内的完整发布仓库 52 项通过日志。
31 号 Gloo 为真实单机双 CPU 进程、手工 SUM、加权梯度及一步 SGD，需要启用 Gloo 的 PyTorch。
32/37 为给定成本模型，无硬件时间。33 为 CPU 物理页池、共享及写时复制，gather 会额外物化连续 K/V。
34 为条件概率小模型；首 token 频率不是完整序列检验或速度结果。
35 为一个 LoRA SGD 步与均匀有损 4-bit 打包，不是 NF4/QLoRA。
36 串行 CPU 专家输出及梯度与密集参考对照；容量溢出丢弃会改变输出。
全部实验均未执行真实 GPU 测量。项目及阅读理解仍独立验收。

课程专题：https://liangqianxing.github.io/learning/cmu-15-779/
GitHub：https://github.com/liangqianxing/cmu-15-779-labs
