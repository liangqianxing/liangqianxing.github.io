# 分块 Attention 与在线 Softmax

本包是 CMU 15-779 学习记录 08 的冻结代码和原始 CPU 结果。

使用 Python 3.11：

```bash
python3.11 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python 28_attention_online_softmax.py --output results/attention-rerun.json
.venv/bin/python 28_attention_online_softmax.py --n 17 --d 8 --value-dim 4 --query-block 8 --key-block 5 --causal --dtype float32 --output results/causal-rerun.json
.venv/bin/python -m unittest discover -s tests -v
```

包含 14 项归约/Attention 测试，测试文件加载归约模块，所以同时附上 27_tree_reduction.py。JSON 为 2026-10-16 原始报告，复跑请另存。只验证 CPU 单头前向算法；没有 GPU kernel、计时、峰值内存、训练/反向、dropout、padding mask 或全遮蔽行的验证。单个分数块大小不是总内存峰值。

代码版本：https://github.com/liangqianxing/cmu-15-779-labs/tree/201587e7b00637567e969368d3085a6ce490154c
