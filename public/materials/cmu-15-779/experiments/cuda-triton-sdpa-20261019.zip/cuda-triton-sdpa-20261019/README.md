# CUDA / Triton / SDPA GPU 续验

CMU 15-779 个人配套实验的冻结发布包，原始报告保留不变，复跑请使用另存路径。

复现环境与命令见 GPU_REPRODUCE.md。需要 NVIDIA CUDA 主机；发布端只核对原始输出和哈希，没有在 Mac 复跑 GPU。包内不含 CPU 历史练习。

FILES.sha256.json 保存本包各文件 SHA-256；它不包含自身。
