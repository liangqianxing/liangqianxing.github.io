# CMU 15-779：PyTorch 入门实验（2026-10-13）

对应学习记录：
https://liangqianxing.github.io/posts/cmu-15-779-pytorch-autograd-linear-regression/

本目录保留这次练习结束时的三个脚本。实验环境为 macOS ARM64、Python 3.11.15、PyTorch 2.14.1，使用 CPU 和默认 float32 张量。

## 运行

进入本目录后执行：

```bash
python3.11 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python 01_autograd.py
.venv/bin/python 02_SGD.py
.venv/bin/python 03_linear.py
```

## 结果核对

- `01_autograd.py`：对 `(w - 3) ** 2` 手动做 10 次梯度下降。当前学习率为 0.01，最后打印 `w=0.5488, loss=6.0085`。改成 0.1 后，最后为 `w=2.6779, loss=0.1038`。
- `02_SGD.py`：以学习率 0.1 做 10 次普通 SGD 更新，最后为 `w=2.6779,loss=0.1038`，与相同学习率下的手动更新一致。
- `03_linear.py`：输入 `[1, 2, 3, 4]`，目标 `[2, 4, 6, 8]`，使用 `w * x` 训练 100 次。最后打印 `w=2.0000,loss=0.0000`，新输入 `[5, 6]` 的预测为 `[10.0000, 12.0000]`。

打印结果做过舍入，显示损失为 0.0000 不表示它在浮点运算中严格等于零。

正文保留了最初的标量求导示例，以及 `w * 4` 写错后的现象和解释；这里的 `03_linear.py` 已修正为 `w * x`。
