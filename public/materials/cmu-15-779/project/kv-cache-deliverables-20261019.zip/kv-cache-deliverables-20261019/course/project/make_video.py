"""Create a 9-minute Chinese synthetic-voice project presentation with local tools."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess

from PIL import Image, ImageDraw, ImageFont
import imageio_ffmpeg

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
WORK = ROOT / "build/project-video"
OUT = ROOT / "output/video"
WORK.mkdir(parents=True, exist_ok=True)
OUT.mkdir(parents=True, exist_ok=True)
FFMPEG = imageio_ffmpeg.get_ffmpeg_exe()
FONT = "/System/Library/Fonts/Supplemental/Arial Unicode.ttf"

SCENES = [
    ("KV cache 的页大小与前缀共享", ["研究对象：CPU 缓存管理组件", "比较空间、复制量与实现成本", "公开方法复现与分析；Codex 辅助制作"], None,
     "这份展示介绍一个围绕大模型服务缓存管理的课程自学项目。问题是，分页缓存的页大小，以及共享前缀是否对齐，会怎样影响空间和数据复制。项目使用真实的CPU张量，实现页池、引用计数和写时复制，再和连续存储方案比较。它没有运行完整语言模型，也没有把缓存空间减少等同于服务加速。图表和数字都来自保留的实验记录。视频由系统合成语音讲解，是辅助学习材料，不是学习者本人录制或正式提交的证明。下面依次介绍问题、相关工作、实现、实验设计、结果以及限制。"),
    ("问题：增长中的 KV cache", ["静态最大长度预留可能浪费空间", "动态拼接会反复复制旧 token", "共享前缀的收益受页边界影响"], None,
     "自回归解码会保留已经生成位置的键和值，后续查询需要访问这些缓存。如果提前为每个请求预留最大长度，短请求会留下很多空位。如果每次追加都重新拼接连续张量，逻辑长度虽然紧凑，旧数据却会不断移动。分页把逻辑位置映射到物理块，可以按需增长，也可以让多个分支引用相同前缀。不过一页内只要还留有未使用位置，就存在内部碎片。共享前缀结束在半页时，分支写入还可能触发复制。因此项目不只问分页能否节省空间，而是问什么条件下节省、又在哪些地方付出代价。"),
    ("相关工作与本项目的边界", ["PagedAttention：block table、共享、COW", "SGLang：RadixAttention 与缓存感知执行", "本项目：已知前缀 fork；CPU gather"], None,
     "第一项相关工作是PagedAttention。它把逻辑键值块映射到物理块，并设计直接沿页表访问的GPU注意力内核；共享和写时复制也属于其系统设计。第二项是SGLang，它进一步用基数树组织可复用前缀，结合结构化语言和缓存感知执行。本项目采用这些公开概念，独立编写CPU分配器和实验代码。为了隔离页大小的影响，公共前缀由工作负载直接提供，没有实现自动前缀搜索、驱逐或完整运行时。注意力之前还会把分页内容收集成连续张量。这样可以检查语义，但不能继承原论文GPU内核的性能结论。"),
    ("实现：页表、引用计数与分支", ["fork 共享物理页，增加引用计数", "共享的部分页在写入前复制", "最后一个引用释放后归还物理页"], "architecture.png",
     "实现包含成对的键值页池、空闲页列表、每个序列的逻辑页表和长度，以及物理页引用计数。创建分支时复制页表引用，不立即复制键和值。追加落在新页边界时分配新页；如果落在仍被其他分支共享的部分页，则先申请新页，复制已有有效位置，再写入新数据。其余分支继续指向旧页。释放序列会减少对应引用，只有最后一个引用消失才归还页面。内存不足必须在改变已有状态之前失败。图中所有方案最终使用同一个注意力表达式，因此可以将存储管理与数值正确性分开检查。"),
    ("实验设计：210 组配置", ["5 类工作负载 × 3 个种子", "前缀长度：0、3、31、32、63", "页大小：2、4、8、16、32、64", "每配置 warmup 1 次，计时 7 次"], None,
     "实验共有五类合成工作负载，公共前缀长度分别是零、三、三十一、三十二和六十三。每类有八个请求，使用不同提示词后缀和一到八个解码位置。键和值的宽度都是十六，采用双精度。比较静态最大长度预留、动态拼接、独立分页和共享分页；两个分页方案各扫描六种页大小。每类使用三个固定种子，合计二百一十组配置。每组先预热一次，再计时七次，每轮打乱方案顺序，合计一千四百七十次计时。原始数据保存环境、源码哈希、误差、字节计数、复制量和每次时间，避免只挑选获胜样本。"),
    ("正确性先于性能", ["每次解码与完整连续前缀核对", "随机 fork / append / release 对照", "新页与 COW 两种 OOM 都保持原状态", "210 组输出的最大观测误差为 0"], None,
     "正确性检查覆盖每个解码位置，参考结果直接来自完整的连续键和值，不依赖被测缓存页表。所有记录配置的最大观测误差都是零。随机测试还在不同页大小下反复创建分支、截取前缀、追加和释放，并在每一步把所有活跃序列与独立存储比较。父序列不能因为子分支写入而改变。两种内存不足路径也分别检查，一种是新页分配失败，另一种是写时复制失败。此外，页计数和部分前缀复制量与解析公式对照。这些有限测试支持当前实现，但不代表对任意并发执行、任意浮点输入或所有硬件给出形式证明。"),
    ("结果一：共享依赖完整前缀块", ["31-token 前缀：B=4 为 29 KiB", "同一工作负载：B=32 为 112 KiB", "粗页可能超过静态预留的 92 KiB"], "video_storage.png",
     "最明显的结果来自三十一位置的公共前缀。页大小为四时，共享方案保留二十九KiB活跃键值槽位，而独立分页需要七十八KiB。页大小改成三十二时，公共前缀没有覆盖一个完整页。各个分支继续写入后，原本的部分页必须独立存在，共享收益消失，活跃槽位达到一百一十二KiB，甚至高于静态预留的九十二KiB。三十二位置前缀与三十二页大小对齐时又能共享完整块，但请求尾部浪费仍可能较大。图中说明的是对齐和内部碎片之间的关系，不能直接读成真实硬件上最佳页大小的推荐。"),
    ("结果二：复制量与实际访存不同", ["31-token 前缀：B=4 复制 21 个旧槽", "B=32 复制 217 个旧槽", "动态拼接复制 1,140 个旧槽", "这些计数排除 gather 与初始写入"], None,
     "在八个请求都发生分歧后，完整前缀块可以共用，部分前缀页则需要让除一个分支之外的其他分支复制。于是旧槽复制量等于请求数减一，乘以前缀长度对页大小的余数。三十一前缀、页大小四的结果是二十一个旧槽；页大小三十二则是二百一十七个。动态拼接在同一工作负载中累计搬动一千一百四十个旧槽。不过这个比较必须限定范围：它没有计入最初的提示词写入，也没有计入每次注意力之前的收集操作，更不是测量显存总线或CPU内存总线流量。减少这一个复制计数，不能独立证明整体程序更快。"),
    ("结果三：活跃页不等于进程峰值", ["共享 B=4：活跃槽位 29 KiB", "同一配置的预分配页池仍为 78 KiB", "不含临时张量、Python 对象与分配器", "没有测量 RSS 或进程峰值内存"], None,
     "项目特别区分活跃页和预分配页池。三十一前缀、页大小四的共享方案虽然只有二十九KiB活跃槽位，整个页池张量依然预留了七十八KiB。释放逻辑页能够让后续请求复用这些页，但不会让张量自动缩小，也不一定把内存还给操作系统。动态拼接的最终长度同样不能代表拼接时旧张量与新张量重叠存在的峰值。这里所有存储指标都排除了查询、输入、临时注意力结果、收集张量、Python元数据和分配器开销。因此报告没有把活跃槽位节省描述成进程峰值内存节省。这个边界对解读系统实验非常重要。"),
    ("结果四：这份 CPU 分页实现更慢", ["CPU 计时包含分配、插入、fork、追加", "也包含 gather、attention 和输出整理", "共享比独立分页快，仍慢于连续基线", "初次编译与 GPU 结果均未混入"], "latency.png",
     "时间结果没有呈现所有优化都获胜的故事。以三十一前缀的一个种子为例，动态拼接完整路径中位数约为零点三五毫秒，共享分页、页大小四约为一点一零毫秒，独立分页约为二点二六毫秒。共享减少了重复提示词插入，因此优于独立分页，但两者仍慢于连续基线。原因包括每个位置的Python处理，以及为了复用相同注意力表达式而物化连续键值。计时包含分配、插入、分支、追加、收集、注意力和结果整理，排除输入生成与正确性断言。这不是孤立内核计时，更不是端到端语言模型服务延迟。"),
    ("限制与后续验证", ["合成单头 K/V/Q；无完整语言模型", "保留所有请求；无在线准入与驱逐", "后来授权的 CUDA 验证单独归档", "吞吐、质量和多卡结论尚无证据"], None,
     "主要限制包括合成的单头键值、已知公共前缀、所有请求一直保留，以及没有在线到达、准入、驱逐和多层模型。真实复用必须包含相同模型版本、词元化、位置和完整因果上下文，不能看见相同后缀就共享缓存。用户后来提供了CUDA服务器，基础CUDA、Triton和显式Flash后端验证已经单独执行并归档。这些结果不会把本项目的CPU缓存数据变成GPU分页吞吐证据。下一步若扩展系统，应直接在注意力内核中沿页表读取，并加入容量限制、真实请求时序和吞吐延迟联合评估，同时保持正确性检查。"),
    ("结论与复现入口", ["完整前缀块带来可核对的共享收益", "页尾浪费与 COW 可能抵消收益", "空间计数、页池与时间应分别报告", "代码、原始数据、报告与测试均已保留"], None,
     "这个项目得到三点有边界的结论。第一，分支发生分歧后，完整公共前缀块决定仍能共享多少存储，部分页需要写时复制。第二，页大小变粗可能增加尾部浪费，也可能完全失去短前缀复用，分页不保证始终比静态预留节省槽位。第三，活跃槽位、预分配池、复制计数和运行时间必须分别报告，不能互相代替。所有配置输出与参考一致，但CPU分页实现仍慢于连续基线。仓库保存了实验脚本、固定种子、原始样本、测试、提案、阶段记录和MLSys格式报告。学习者的理解、身份以及正式课程参与和提交仍需由真实证据确认。"),
]


def call(command):
    return subprocess.run(command, check=True, capture_output=True, text=True)


def duration(path):
    result = subprocess.run([FFMPEG, "-i", str(path)], capture_output=True, text=True)
    match = re.search(r"Duration: (\d+):(\d+):(\d+\.\d+)", result.stderr)
    if not match:
        raise RuntimeError("Could not inspect media duration")
    h, m, s = map(float, match.groups())
    return 3600*h+60*m+s


def frame(index, title, bullets, figure):
    canvas = Image.new("RGB", (1280, 720), "#f6f8fb")
    draw = ImageDraw.Draw(canvas)
    draw.rectangle((0, 0, 1280, 16), fill="#176b7a")
    draw.text((65, 48), title, font=ImageFont.truetype(FONT, 42), fill="#173746")
    y = 130
    for line in bullets:
        draw.ellipse((68, y+15, 79, y+26), fill="#176b7a")
        draw.text((98, y), line, font=ImageFont.truetype(FONT, 28), fill="#283b49")
        y += 52
    if figure:
        im = Image.open(HERE / "figures" / figure).convert("RGB")
        available_h = 650-y
        # Charts are large on dedicated visual scenes, while bullets stay short.
        im.thumbnail((1140, available_h))
        canvas.paste(im, ((1280-im.width)//2, y))
    draw.line((65, 665, 1215, 665), fill="#cbd5df", width=2)
    draw.text((65, 681), "CMU 15-779 自学项目 · 合成语音讲解 · Codex 辅助制作", font=ImageFont.truetype(FONT, 18), fill="#586777")
    draw.text((1150, 681), f"{index+1:02d} / 12", font=ImageFont.truetype(FONT, 18), fill="#586777")
    path = WORK / f"scene-{index:02d}.png"
    canvas.save(path)
    return path


def main():
    narration = []
    transcript = ["# KV cache 项目中文讲稿", "", "系统合成语音；Codex 辅助制作，不代表学习者本人录制。", ""]
    for i, (title, bullets, figure, text) in enumerate(SCENES):
        textfile, audio = WORK / f"scene-{i:02d}.txt", WORK / f"scene-{i:02d}.aiff"
        cached = audio.exists() and textfile.exists() and textfile.read_text() == text
        textfile.write_text(text)
        if not cached:
            call(["say", "-v", "Tingting", "-r", "210", "-f", str(textfile), "-o", str(audio)])
        narration.append({"audio": audio, "duration": duration(audio), "frame": frame(i, title, bullets, figure)})
        transcript += [f"## {i+1}. {title}", "", text, ""]
    total = sum(n["duration"] for n in narration)
    tempo = total/540.0
    if not 0.5 <= tempo <= 2:
        raise RuntimeError(f"Narration duration requires excessive tempo adjustment: {total}")
    clips = []
    cursor = 0
    chapters = []
    for i, item in enumerate(narration):
        clip = WORK / f"clip-{i:02d}.mp4"
        length = item["duration"]/tempo
        call([FFMPEG, "-y", "-loglevel", "error", "-loop", "1", "-framerate", "1", "-i", str(item["frame"]),
              "-i", str(item["audio"]), "-af", f"atempo={tempo:.8f},apad", "-vf", "fps=10",
              "-c:v", "libx264", "-threads", "2", "-preset", "fast", "-tune", "stillimage", "-pix_fmt", "yuv420p",
              "-c:a", "aac", "-b:a", "96k", "-t", f"{length:.4f}", str(clip)])
        clips.append(clip)
        chapters.append({"title": SCENES[i][0], "start_seconds": cursor, "planned_duration_seconds": length})
        cursor += length
        print("Rendered scene", i+1, flush=True)
    listing = WORK / "clips.txt"
    listing.write_text("".join("file '"+str(p)+"'\n" for p in clips))
    target = OUT / "kv-cache-presentation.mp4"
    call([FFMPEG, "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", str(listing), "-c", "copy", "-movflags", "+faststart", str(target)])
    # Decode all frames/audio to ensure the final container is readable.
    call([FFMPEG, "-v", "error", "-i", str(target), "-f", "null", "-"])
    actual = duration(target)
    if not 480 <= actual <= 600:
        raise RuntimeError("Final video falls outside the required 8-10 minute range")
    (HERE / "presentation_transcript.md").write_text("\n".join(transcript))
    (OUT / "presentation_manifest.json").write_text(json.dumps({"recorded_at": datetime.now(timezone.utc).isoformat(),
        "path": str(target.relative_to(ROOT)), "duration_seconds": actual, "synthetic_voice": "macOS Tingting",
        "voice_tempo_multiplier": tempo, "original_speech_seconds": total, "chapters": chapters,
        "sha256": hashlib.sha256(target.read_bytes()).hexdigest(), "full_decode_check": "passed",
        "status": "AI-assisted study presentation; not learner recording or formal submission"}, ensure_ascii=False, indent=2)+"\n")
    print("Video", target, "duration", actual, "tempo", tempo)


if __name__ == "__main__":
    main()
